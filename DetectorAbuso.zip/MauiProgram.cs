using DetectorAbuso.Servicios;
using Microsoft.Extensions.Logging;
using Plugin.Maui.Audio;

namespace DetectorAbuso
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var constructor = MauiApp.CreateBuilder();
            constructor
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf",  "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                })
                .AddAudio();

            var s = constructor.Services;

            // ── Modelo y transcripción ────────────────────────────────────────────
            s.AddSingleton<ModeloGestor>();
            s.AddSingleton<WhisperServ>();

            // ── Audio ─────────────────────────────────────────────────────────────
            s.AddSingleton(new AudioBuffer(segundosMaximos: 20));
            s.AddSingleton<AudioGrabador>();

            // ── Análisis y monitor ────────────────────────────────────────────────
            s.AddSingleton<ProbAnalizador>();
            s.AddSingleton<MonitorServ>();

            // ── UI ────────────────────────────────────────────────────────────────
            s.AddTransient<SplashPage>();
            s.AddTransient<MainPage>();

#if DEBUG
            constructor.Logging.AddDebug();
#endif

            return constructor.Build();
        }
    }
}
