namespace DetectorAbuso.Models
{
    /// <summary>
    /// Representa un momento de tensión ambiental registrado.
    /// Nombre público neutro: "registro de entorno".
    /// </summary>
    public class Incidente
    {
        // ── Datos base ───────────────────────────────────────────
        public DateTime Fecha         { get; set; }
        public int      Probabilidad  { get; set; }   // 0-100
        public string   Transcripcion { get; set; } = string.Empty;
        public string   Categorias    { get; set; } = string.Empty; // "insulto, amenaza_fisica"

        // ── Propiedades calculadas para la UI ────────────────────

        /// <summary>Fecha legible: "24 jun · 10:32"</summary>
        public string FechaFormateada =>
            Fecha.ToString("dd MMM · HH:mm").ToLower();

        /// <summary>Nivel de tensión en texto neutro.</summary>
        public string NivelTexto => Probabilidad switch
        {
            >= 80 => "NIVEL ALTO",
            >= 55 => "NIVEL MEDIO",
            _     => "NIVEL BAJO"
        };

        /// <summary>Probabilidad normalizada 0.0-1.0 para ProgressBar.</summary>
        public double ProbabilidadNorm => Probabilidad / 100.0;
    }
}
