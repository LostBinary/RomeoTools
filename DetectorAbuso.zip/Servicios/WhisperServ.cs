using Microsoft.Extensions.Logging;
using Whisper.net;

namespace DetectorAbuso.Servicios
{
    /// <summary>
    /// Servicio de transcripción local usando Whisper.NET (modelo tiny).
    /// Carga el modelo en memoria la primera vez que se usa (lazy).
    /// Solo una transcripción simultánea vía SemaphoreSlim.
    /// </summary>
    public class WhisperServ : IAsyncDisposable
    {
        private readonly ModeloGestor         _modeloGestor;
        private readonly ILogger<WhisperServ> _logger;

        private WhisperFactory?   _factory;
        private WhisperProcessor? _processor;
        private readonly SemaphoreSlim _semaforo = new(1, 1);

        public WhisperServ(ModeloGestor modeloGestor, ILogger<WhisperServ> logger)
        {
            _modeloGestor = modeloGestor;
            _logger       = logger;
        }

        // ── API pública ───────────────────────────────────────────────────────────

        public async Task<string> TranscribirAsync(
            byte[]            audioBytes,
            CancellationToken ct = default)
        {
            if (audioBytes == null || audioBytes.Length == 0)
                return string.Empty;

            if (!_modeloGestor.ModeloDisponible)
            {
                _logger.LogWarning("Modelo no disponible. Transcripción omitida.");
                return string.Empty;
            }

            await _semaforo.WaitAsync(ct);
            try
            {
                AsegurarInicializado();
                if (_processor == null) return string.Empty;

                using var stream    = new MemoryStream(audioBytes);
                var       segmentos = new List<string>();

                await foreach (var seg in _processor.ProcessAsync(stream, ct))
                {
                    if (!string.IsNullOrWhiteSpace(seg.Text))
                        segmentos.Add(seg.Text.Trim());
                }

                var resultado = string.Join(" ", segmentos);

                _logger.LogDebug("Transcripción: '{Texto}'",
                    resultado.Length > 80 ? resultado[..80] + "…" : resultado);

                return resultado;
            }
            catch (OperationCanceledException) { return string.Empty; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error durante la transcripción.");
                return string.Empty;
            }
            finally
            {
                _semaforo.Release();
            }
        }

        // ── Inicialización lazy (síncrona — Build() no es async) ──────────────────

        private void AsegurarInicializado()
        {
            if (_processor != null) return;

            _logger.LogInformation("Cargando modelo Whisper desde {Ruta}",
                _modeloGestor.RutaModelo);

            _factory   = WhisperFactory.FromPath(_modeloGestor.RutaModelo);
            _processor = _factory
                .CreateBuilder()
                .WithLanguage("es")
                .Build();

            _logger.LogInformation("Modelo Whisper cargado.");
        }

        // ── IAsyncDisposable ──────────────────────────────────────────────────────
        public async ValueTask DisposeAsync()
        {
            if (_processor != null) await _processor.DisposeAsync();
            _factory?.Dispose();
            _semaforo.Dispose();
        }
    }
}
