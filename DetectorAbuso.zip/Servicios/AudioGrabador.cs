using Microsoft.Extensions.Logging;
using Plugin.Maui.Audio;

namespace DetectorAbuso.Servicios
{
    /// <summary>
    /// Grabador de audio continuo para Android.
    /// Usa <see cref="Plugin.Maui.Audio"/> para capturar el micrófono en chunks
    /// de duración fija y los vuelca en el <see cref="AudioBuffer"/>.
    ///
    /// Ciclo de vida:
    ///   IniciarAsync() → graba en loop hasta que se llame a DetenerAsync()
    ///
    /// Cada chunk dura <see cref="DuracionChunkSeg"/> segundos.
    /// El buffer circular retiene los últimos 20 s por defecto.
    /// </summary>
    public class AudioGrabador : IAsyncDisposable
    {
        // ── Dependencias ──────────────────────────────────────────────────────────
        private readonly IAudioManager   _audioManager;
        private readonly AudioBuffer     _buffer;
        private readonly ILogger<AudioGrabador> _logger;

        // ── Configuración ─────────────────────────────────────────────────────────
        /// <summary>Duración de cada chunk grabado, en segundos.</summary>
        public int DuracionChunkSeg { get; set; } = 5;

        // ── Estado ────────────────────────────────────────────────────────────────
        private CancellationTokenSource? _cts;
        private IAudioRecorder?          _recorder;
        public  bool EstaGrabando { get; private set; }

        // ── Constructor ───────────────────────────────────────────────────────────
        public AudioGrabador(
            IAudioManager audioManager,
            AudioBuffer   buffer,
            ILogger<AudioGrabador> logger)
        {
            _audioManager = audioManager;
            _buffer       = buffer;
            _logger       = logger;
        }

        // ── API pública ───────────────────────────────────────────────────────────

        /// <summary>
        /// Solicita permiso de micrófono y arranca el loop de grabación.
        /// Devuelve false si el permiso es denegado.
        /// </summary>
        public async Task<bool> IniciarAsync()
        {
            if (EstaGrabando)
            {
                _logger.LogWarning("AudioGrabador: ya está grabando.");
                return true;
            }

            // ── Permiso de micrófono (Android) ───────────────────────────────────
            var estado = await Permissions.RequestAsync<Permissions.Microphone>();
            if (estado != PermissionStatus.Granted)
            {
                _logger.LogWarning("Permiso de micrófono denegado.");
                return false;
            }

            _cts = new CancellationTokenSource();
            EstaGrabando = true;

            // Lanzar el loop en background — no bloquea la UI
            _ = Task.Run(() => LoopGrabacionAsync(_cts.Token));

            _logger.LogInformation("AudioGrabador iniciado. Chunk={Seg}s", DuracionChunkSeg);
            return true;
        }

        /// <summary>
        /// Detiene la grabación y espera a que el chunk actual termine.
        /// </summary>
        public async Task DetenerAsync()
        {
            if (!EstaGrabando) return;

            _cts?.Cancel();
            await PararRecorderAsync();

            EstaGrabando = false;
            _logger.LogInformation("AudioGrabador detenido.");
        }

        // ── Loop interno ──────────────────────────────────────────────────────────

        private async Task LoopGrabacionAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var chunk = await GrabarChunkAsync(DuracionChunkSeg, ct);
                    if (chunk != null)
                        _buffer.Escribir(chunk, TimeSpan.FromSeconds(DuracionChunkSeg));
                }
                catch (OperationCanceledException)
                {
                    break; // Detención limpia
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error en chunk de grabación.");
                    // Breve pausa antes de reintentar para no saturar en error continuo
                    await Task.Delay(1000, ct).ConfigureAwait(false);
                }
            }
        }

        /// <summary>
        /// Graba un único chunk de <paramref name="segundos"/> segundos.
        /// Devuelve los bytes del WAV grabado, o null si hay error.
        /// </summary>
        private async Task<byte[]?> GrabarChunkAsync(int segundos, CancellationToken ct)
        {
            _recorder = _audioManager.CreateRecorder();

            await _recorder.StartAsync();

            // Esperar la duración del chunk (o cancelación)
            await Task.Delay(TimeSpan.FromSeconds(segundos), ct);

            var audioSource = await _recorder.StopAsync();

            if (audioSource == null)
            {
                _logger.LogWarning("Chunk vacío devuelto por el grabador.");
                return null;
            }

            // Leer el stream como bytes
            using var stream = audioSource.GetAudioStream();
            using var ms     = new MemoryStream();
            await stream.CopyToAsync(ms, ct);
            return ms.ToArray();
        }

        private async Task PararRecorderAsync()
        {
            if (_recorder == null) return;
            try   { await _recorder.StopAsync(); }
            catch { /* ya parado */ }
            _recorder = null;
        }

        // ── IAsyncDisposable ──────────────────────────────────────────────────────
        public async ValueTask DisposeAsync()
        {
            await DetenerAsync();
            _cts?.Dispose();
        }
    }
}
