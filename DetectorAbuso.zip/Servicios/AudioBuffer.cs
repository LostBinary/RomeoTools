namespace DetectorAbuso.Servicios
{
    /// <summary>
    /// Buffer circular que conserva los últimos <see cref="SegundosMaximos"/> segundos
    /// de audio grabado, en forma de chunks de bytes (PCM/WAV parciales).
    ///
    /// Hilo-seguro: usa lock interno para que el grabador y el consumidor
    /// puedan acceder concurrentemente sin carreras.
    /// </summary>
    public class AudioBuffer
    {
        // ── Configuración ─────────────────────────────────────────────────────────
        public int SegundosMaximos { get; }

        // ── Estado interno ────────────────────────────────────────────────────────
        private readonly Queue<AudioChunk> _chunks = new();
        private readonly object _lock = new();

        // ── Constructor ───────────────────────────────────────────────────────────
        public AudioBuffer(int segundosMaximos = 20)
        {
            if (segundosMaximos <= 0)
                throw new ArgumentOutOfRangeException(nameof(segundosMaximos));

            SegundosMaximos = segundosMaximos;
        }

        // ── Escritura ─────────────────────────────────────────────────────────────
        /// <summary>
        /// Añade un chunk al buffer. Si la ventana temporal supera el máximo,
        /// descarta los chunks más antiguos.
        /// </summary>
        public void Escribir(byte[] datos, TimeSpan duracion)
        {
            if (datos == null || datos.Length == 0) return;

            var chunk = new AudioChunk(datos, duracion, DateTime.UtcNow);

            lock (_lock)
            {
                _chunks.Enqueue(chunk);
                Podar();
            }
        }

        // ── Lectura ───────────────────────────────────────────────────────────────
        /// <summary>
        /// Devuelve una copia de todos los chunks actuales ordenados por tiempo.
        /// No vacía el buffer.
        /// </summary>
        public IReadOnlyList<AudioChunk> LeerTodo()
        {
            lock (_lock)
            {
                return _chunks.ToList().AsReadOnly();
            }
        }

        /// <summary>
        /// Concatena todos los chunks en un único array de bytes.
        /// Útil para pasar el audio a Whisper como stream continuo.
        /// </summary>
        public byte[] ExportarBytes()
        {
            lock (_lock)
            {
                int total = _chunks.Sum(c => c.Datos.Length);
                var resultado = new byte[total];
                int offset = 0;
                foreach (var chunk in _chunks)
                {
                    Buffer.BlockCopy(chunk.Datos, 0, resultado, offset, chunk.Datos.Length);
                    offset += chunk.Datos.Length;
                }
                return resultado;
            }
        }

        /// <summary>
        /// Vacía el buffer completamente.
        /// </summary>
        public void Limpiar()
        {
            lock (_lock) { _chunks.Clear(); }
        }

        /// <summary>Duración total acumulada en el buffer.</summary>
        public TimeSpan DuracionTotal
        {
            get
            {
                lock (_lock)
                {
                    return TimeSpan.FromTicks(_chunks.Sum(c => c.Duracion.Ticks));
                }
            }
        }

        // ── Privados ──────────────────────────────────────────────────────────────
        /// <summary>
        /// Elimina chunks del frente hasta que la duración total
        /// no supere SegundosMaximos.
        /// </summary>
        private void Podar()
        {
            var limite = TimeSpan.FromSeconds(SegundosMaximos);
            while (_chunks.Count > 0 && DuracionTotalSinLock() > limite)
                _chunks.Dequeue();
        }

        private TimeSpan DuracionTotalSinLock() =>
            TimeSpan.FromTicks(_chunks.Sum(c => c.Duracion.Ticks));
    }

    // ── DTO de chunk ──────────────────────────────────────────────────────────────
    public record AudioChunk(byte[] Datos, TimeSpan Duracion, DateTime Timestamp);
}
