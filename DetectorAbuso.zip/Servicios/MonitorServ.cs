using DetectorAbuso.Models;
using Microsoft.Extensions.Logging;

namespace DetectorAbuso.Servicios
{
    public class MonitorServ : IAsyncDisposable
    {
        private readonly ProbAnalizador       _analizador;
        private readonly AudioGrabador        _grabador;
        private readonly AudioBuffer          _buffer;
        private readonly WhisperServ          _whisper;
        private readonly ILogger<MonitorServ> _logger;

        private CancellationTokenSource? _ctsProcesado;

        public bool EstaActivo { get; private set; }

        public event Action<Incidente>? IncidenteDetectado;

        // ── Constructor ───────────────────────────────────────────────────────────
        public MonitorServ(
            ProbAnalizador       analizador,
            AudioGrabador        grabador,
            AudioBuffer          buffer,
            WhisperServ          whisper,
            ILogger<MonitorServ> logger)
        {
            _analizador = analizador;
            _grabador   = grabador;
            _buffer     = buffer;
            _whisper    = whisper;
            _logger     = logger;
        }

        // ── Control ───────────────────────────────────────────────────────────────
        public async Task<bool> IniciarAsync()
        {
            if (EstaActivo) return true;

            bool permiso = await _grabador.IniciarAsync();
            if (!permiso) return false;

            EstaActivo   = true;
            _ctsProcesado = new CancellationTokenSource();

            // Loop de procesado: cada vez que el grabador completa un chunk,
            // transcribimos el buffer acumulado y analizamos
            _ = Task.Run(() => LoopProcesadoAsync(_ctsProcesado.Token));

            _logger.LogInformation("Monitor iniciado.");
            return true;
        }

        public async Task DetenerAsync()
        {
            if (!EstaActivo) return;

            _ctsProcesado?.Cancel();
            await _grabador.DetenerAsync();

            EstaActivo = false;
            _logger.LogInformation("Monitor detenido.");
        }

        // ── Loop de procesado ─────────────────────────────────────────────────────
        /// <summary>
        /// Cada <see cref="IntervaloAnalisisSeg"/> segundos, exporta el buffer,
        /// transcribe y analiza. Se solapa con la grabación continua.
        /// </summary>
        private int IntervaloAnalisisSeg => _grabador.DuracionChunkSeg;

        private async Task LoopProcesadoAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    // Esperar un ciclo de chunk antes de analizar
                    await Task.Delay(
                        TimeSpan.FromSeconds(IntervaloAnalisisSeg), ct);

                    await ProcesarBufferAsync(ct);
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error en loop de procesado.");
                }
            }
        }

        private async Task ProcesarBufferAsync(CancellationToken ct)
        {
            var bytes = _buffer.ExportarBytes();
            if (bytes.Length == 0) return;

            string texto = await _whisper.TranscribirAsync(bytes, ct);
            if (string.IsNullOrWhiteSpace(texto)) return;

            AnalizaTexto(texto);
        }

        // ── Análisis de texto ─────────────────────────────────────────────────────
        public Incidente? AnalizaTexto(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return null;

            var detalle = _analizador.AnalizarDetalle(texto);

            _logger.LogDebug("Análisis: prob={Prob} cats=[{Cats}]",
                detalle.Probabilidad, detalle.ResumenCategorias);

            if (!detalle.EsRelevante) return null;

            var incidente = new Incidente
            {
                Fecha         = DateTime.Now,
                Transcripcion = texto,
                Probabilidad  = detalle.Probabilidad,
                Categorias    = detalle.ResumenCategorias
            };

            IncidenteDetectado?.Invoke(incidente);
            return incidente;
        }

        // ── IAsyncDisposable ──────────────────────────────────────────────────────
        public async ValueTask DisposeAsync()
        {
            _ctsProcesado?.Cancel();
            _ctsProcesado?.Dispose();
            await _grabador.DisposeAsync();
            await _whisper.DisposeAsync();
        }
    }
}
