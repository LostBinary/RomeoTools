namespace DetectorAbuso
{
    using DetectorAbuso.Servicios;

    public partial class SplashPage : ContentPage
    {
        private readonly ModeloGestor _modeloGestor;

        public SplashPage(ModeloGestor modeloGestor)
        {
            InitializeComponent();
            _modeloGestor = modeloGestor;
        }

        // ── Arranque ──────────────────────────────────────────────────────────────
        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await IniciarCargaAsync();
        }

        private async Task IniciarCargaAsync()
        {
            MostrarError(visible: false);

            // Si el modelo ya está listo, saltar directo
            if (_modeloGestor.ModeloDisponible)
            {
                await NavegerAMain();
                return;
            }

            // Mostrar bloque de progreso y descargar
            BloquePreparing.IsVisible = true;
            MensajeLabel.Text = "Descargando componente de análisis…";

            try
            {
                var progreso = new Progress<double>(p =>
                {
                    MainThread.BeginInvokeOnMainThread(() =>
                    {
                        BarraProgreso.Progress  = p;
                        PorcentajeLabel.Text    = p < 1.0
                            ? $"{(int)(p * 100)} %"
                            : string.Empty;
                    });
                });

                await _modeloGestor.DescargarAsync(progreso);

                MensajeLabel.Text = "Listo.";
                await Task.Delay(600); // pausa breve para que el usuario vea el 100 %
                await NavegerAMain();
            }
            catch (OperationCanceledException)
            {
                MostrarError("Descarga cancelada.");
            }
            catch (Exception ex)
            {
                MostrarError($"No se pudo descargar el componente:\n{ex.Message}");
            }
        }

        // ── Reintentar ────────────────────────────────────────────────────────────
        private async void Reintentar(object sender, EventArgs e)
        {
            await IniciarCargaAsync();
        }

        // ── Navegación ────────────────────────────────────────────────────────────
        private async Task NavegerAMain()
        {
            // Reemplazar SplashPage por MainPage en la pila de navegación
            await Shell.Current.GoToAsync("//main");
        }

        // ── Helpers ───────────────────────────────────────────────────────────────
        private void MostrarError(bool visible, string mensaje = "")
        {
            BloqueError.IsVisible  = visible;
            BloquePreparing.IsVisible = !visible;
            if (visible)
                ErrorLabel.Text = mensaje;
        }

        private void MostrarError(string mensaje) =>
            MostrarError(visible: true, mensaje: mensaje);
    }
}
