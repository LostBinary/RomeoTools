using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace DetectorAbuso.Servicios
{
    /// <summary>
    /// Motor de análisis de probabilidad de abuso verbal/psicológico.
    /// Evalúa texto normalizado por categorías ponderadas, intensificadores,
    /// patrones de frase compuesta y negación contextual.
    /// </summary>
    public class ProbAnalizador
    {
        // ── Categorías con peso base ─────────────────────────────────────────────
        // Cada categoría tiene un nombre (para logging futuro) y un peso por hit.
        // Las frases largas tienen prioridad sobre palabras sueltas.

        private readonly List<(string patron, int peso, string categoria)> _reglas = new()
        {
            // ── Amenazas físicas (peso alto) ─────────────────────────────────────
            ("te voy a pegar",          45, "amenaza_fisica"),
            ("te voy a matar",          60, "amenaza_fisica"),
            ("te voy a hacer dano",     50, "amenaza_fisica"),
            ("voy a pegarte",           45, "amenaza_fisica"),
            ("te rompo",                35, "amenaza_fisica"),
            ("te parto",                35, "amenaza_fisica"),

            // ── Humillación directa ──────────────────────────────────────────────
            ("nadie te quiere",         30, "humillacion"),
            ("no sirves para nada",     30, "humillacion"),
            ("eres lo peor",            25, "humillacion"),
            ("eres una vergüenza",      25, "humillacion"),
            ("eres una verguenza",      25, "humillacion"),
            ("te arrepentiras",         20, "humillacion"),
            ("te vas a arrepentir",     25, "humillacion"),
            ("nunca seras nada",        30, "humillacion"),
            ("nunca seras nada",        30, "humillacion"),
            ("no vales nada",           30, "humillacion"),
            ("sin mi no eres nada",     35, "humillacion"),

            // ── Control y coerción ───────────────────────────────────────────────
            ("te voy a despedir",       20, "coercion"),
            ("te quedo sin trabajo",    20, "coercion"),
            ("haz lo que te digo",      15, "coercion"),
            ("obedece",                 10, "coercion"),
            ("te lo ordeno",            15, "coercion"),
            ("no tienes eleccion",      20, "coercion"),
            ("no tienes opcion",        20, "coercion"),
            ("lo haces o lo haces",     25, "coercion"),
            ("si no te gusta te vas",   20, "coercion"),

            // ── Insultos sueltos (peso medio) ────────────────────────────────────
            ("inutil",                  18, "insulto"),
            ("idiota",                  18, "insulto"),
            ("imbecil",                 18, "insulto"),
            ("estupido",                18, "insulto"),
            ("estupida",                18, "insulto"),
            ("retrasado",               22, "insulto"),
            ("subnormal",               22, "insulto"),
            ("maldito",                 15, "insulto"),
            ("maldita",                 15, "insulto"),
            ("basura",                  20, "insulto"),
            ("inservible",              18, "insulto"),
            ("incompetente",            15, "insulto"),
            ("burro",                   15, "insulto"),
            ("burra",                   15, "insulto"),
            ("tonto",                   12, "insulto"),
            ("tonta",                   12, "insulto"),

            // ── Exclusión y aislamiento ──────────────────────────────────────────
            ("no me hables",            10, "aislamiento"),
            ("no te quiero ver",        15, "aislamiento"),
            ("desaparece",              15, "aislamiento"),
            ("vete de aqui",            12, "aislamiento"),
            ("lárgate",                 15, "aislamiento"),
            ("largate",                 15, "aislamiento"),
            ("fuera de aqui",           15, "aislamiento"),
            ("sal de aqui",             12, "aislamiento"),

            // ── Culpabilización ──────────────────────────────────────────────────
            ("es tu culpa",             18, "culpa"),
            ("la culpa es tuya",        20, "culpa"),
            ("por tu culpa",            18, "culpa"),
            ("me lo has hecho tu",      20, "culpa"),
            ("eres el problema",        18, "culpa"),
            ("eres la problema",        18, "culpa"),
            ("siempre lo arruinas",     22, "culpa"),
            ("siempre lo estropeas",    22, "culpa"),
        };

        // ── Intensificadores (multiplican el score parcial) ──────────────────────
        private readonly List<string> _intensificadores = new()
        {
            "siempre", "nunca", "jamas", "completamente",
            "absolutamente", "totalmente", "de verdad", "en serio",
            "eres un", "eres una", "eres lo"
        };

        // ── Patrones de negación con ventana de 3 palabras ──────────────────────
        // Si una negación precede al patrón en ≤ 3 tokens, reduce el impacto.
        private static readonly string[] _negaciones =
        {
            "no", "tampoco", "nunca diria", "jamas diria", "no creo"
        };

        // ── Umbral de corte (configurable) ───────────────────────────────────────
        public int UmbralMinimo { get; set; } = 50;

        // ── Análisis principal ───────────────────────────────────────────────────
        public int CalcularProb(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return 0;

            string norm = Normalizar(texto);
            string[] tokens = norm.Split(' ', StringSplitOptions.RemoveEmptyEntries);

            int puntuacion  = 0;
            bool intensificado = TieneIntensificador(norm);

            // Rastrear posiciones ya sumadas para evitar doble conteo
            var hitsCubiertos = new HashSet<int>();

            // Ordenar reglas por longitud de patrón desc (frases antes que palabras)
            var reglasPriorizadas = _reglas
                .OrderByDescending(r => r.patron.Length)
                .ToList();

            foreach (var (patron, peso, _) in reglasPriorizadas)
            {
                int idx = norm.IndexOf(patron, StringComparison.Ordinal);
                if (idx < 0) continue;

                // Comprobar si ya fue cubierto por una frase más larga
                if (hitsCubiertos.Contains(idx)) continue;

                // Ventana de negación: buscar negación en los 25 chars anteriores
                bool negado = EstaNeagdo(norm, idx);
                if (negado)
                {
                    puntuacion = Math.Max(0, puntuacion - 5); // penalización leve
                    continue;
                }

                int pesoEfectivo = intensificado ? (int)(peso * 1.3) : peso;
                puntuacion += pesoEfectivo;
                hitsCubiertos.Add(idx);
            }

            return Math.Clamp(puntuacion, 0, 100);
        }

        // ── Desglose para diagnóstico / logging ──────────────────────────────────
        public AnalisisDetalle AnalizarDetalle(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return new AnalisisDetalle(0, new List<HitDetalle>());

            string norm = Normalizar(texto);
            bool intensificado = TieneIntensificador(norm);
            var hits = new List<HitDetalle>();
            var hitsCubiertos = new HashSet<int>();

            var reglasPriorizadas = _reglas
                .OrderByDescending(r => r.patron.Length)
                .ToList();

            int total = 0;

            foreach (var (patron, peso, categoria) in reglasPriorizadas)
            {
                int idx = norm.IndexOf(patron, StringComparison.Ordinal);
                if (idx < 0) continue;
                if (hitsCubiertos.Contains(idx)) continue;

                bool negado = EstaNeagdo(norm, idx);
                int pesoEfectivo = negado ? 0 : (intensificado ? (int)(peso * 1.3) : peso);

                hits.Add(new HitDetalle(patron, categoria, pesoEfectivo, negado));
                if (!negado) total += pesoEfectivo;
                hitsCubiertos.Add(idx);
            }

            return new AnalisisDetalle(Math.Clamp(total, 0, 100), hits);
        }

        // ── Helpers privados ─────────────────────────────────────────────────────

        private static string Normalizar(string texto)
        {
            // Minúsculas + quitar acentos + colapsar espacios
            string lower = texto.ToLowerInvariant();
            string formD = lower.Normalize(NormalizationForm.FormD);
            var sinAcentos = new string(formD
                .Where(c => CharUnicodeInfo.GetUnicodeCategory(c)
                            != UnicodeCategory.NonSpacingMark)
                .ToArray());

            // Colapsar múltiples espacios
            return Regex.Replace(sinAcentos, @"\s+", " ").Trim();
        }

        private bool TieneIntensificador(string normTexto)
        {
            return _intensificadores.Any(i => normTexto.Contains(i));
        }

        private static bool EstaNeagdo(string norm, int idxPatron)
        {
            int ventanaInicio = Math.Max(0, idxPatron - 30);
            string ventana = norm.Substring(ventanaInicio, idxPatron - ventanaInicio);
            return _negaciones.Any(n => ventana.Contains(n));
        }
    }

    // ── DTOs de diagnóstico ──────────────────────────────────────────────────────

    public record HitDetalle(string Patron, string Categoria, int Peso, bool Negado);

    public record AnalisisDetalle(int Probabilidad, List<HitDetalle> Hits)
    {
        public bool EsRelevante => Probabilidad >= 50;
        public string ResumenCategorias =>
            string.Join(", ", Hits
                .Where(h => !h.Negado)
                .Select(h => h.Categoria)
                .Distinct());
    }
}
