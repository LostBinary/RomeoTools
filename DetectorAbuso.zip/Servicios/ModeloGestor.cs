using Microsoft.Extensions.Logging;

namespace DetectorAbuso.Servicios
{
    /// <summary>
    /// Gestiona el ciclo de vida del modelo Whisper tiny:
    /// descarga desde Hugging Face, verificación de tamaño y caché local.
    ///
    /// El modelo se guarda en <see cref="RutaModelo"/> (AppDataDirectory),
    /// que en Android corresponde a almacenamiento interno privado de la app.
    /// </summary>
    public class ModeloGestor
    {
        // ── Constantes ────────────────────────────────────────────────────────────
        private const string UrlModelo =
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin";

        private const string NombreArchivo = "ggml-tiny.bin";

        /// <summary>Tamaño mínimo esperado en bytes (~74 MB).</summary>
        private const long TamanoMinimoBytes = 70_000_000L;

        // ── Rutas ─────────────────────────────────────────────────────────────────
        public string RutaModelo =>
            Path.Combine(FileSystem.AppDataDirectory, NombreArchivo);

        // ── Dependencias ──────────────────────────────────────────────────────────
        private readonly ILogger<ModeloGestor> _logger;

        public ModeloGestor(ILogger<ModeloGestor> logger)
        {
            _logger = logger;
        }

        // ── Estado ────────────────────────────────────────────────────────────────

        /// <summary>
        /// True si el modelo ya está descargado y tiene el tamaño correcto.
        /// </summary>
        public bool ModeloDisponible =>
            File.Exists(RutaModelo) &&
            new FileInfo(RutaModelo).Length >= TamanoMinimoBytes;

        // ── Descarga ──────────────────────────────────────────────────────────────

        /// <summary>
        /// Descarga el modelo con reporte de progreso.
        /// Lanza <see cref="OperationCanceledException"/> si se cancela.
        /// Lanza <see cref="Exception"/> si la descarga falla.
        /// </summary>
        /// <param name="progreso">Callback con valor 0.0–1.0</param>
        /// <param name="ct">Token de cancelación</param>
        public async Task DescargarAsync(
            IProgress<double>?  progreso = null,
            CancellationToken   ct       = default)
        {
            if (ModeloDisponible)
            {
                _logger.LogInformation("Modelo ya disponible en {Ruta}", RutaModelo);
                progreso?.Report(1.0);
                return;
            }

            _logger.LogInformation("Descargando modelo desde {Url}", UrlModelo);

            // Ruta temporal — evita dejar un archivo corrupto si se interrumpe
            string rutaTmp = RutaModelo + ".tmp";

            using var http = new HttpClient();
            http.Timeout = TimeSpan.FromMinutes(10);

            // HEAD para conocer el tamaño total
            long totalBytes = 0;
            try
            {
                using var head = await http.SendAsync(
                    new HttpRequestMessage(HttpMethod.Head, UrlModelo), ct);
                totalBytes = head.Content.Headers.ContentLength ?? 0;
            }
            catch
            {
                // Si el HEAD falla, seguimos sin progreso preciso
                _logger.LogWarning("No se pudo obtener el tamaño del modelo. El progreso será aproximado.");
            }

            using var respuesta = await http.GetAsync(
                UrlModelo,
                HttpCompletionOption.ResponseHeadersRead,
                ct);

            respuesta.EnsureSuccessStatusCode();

            if (totalBytes == 0)
                totalBytes = respuesta.Content.Headers.ContentLength ?? 0;

            await using var streamRed  = await respuesta.Content.ReadAsStreamAsync(ct);
            await using var streamDisk = File.Create(rutaTmp);

            var   buffer       = new byte[81920]; // 80 KB por lectura
            long  bytesLeidos  = 0;
            int   leidos;

            while ((leidos = await streamRed.ReadAsync(buffer, ct)) > 0)
            {
                await streamDisk.WriteAsync(buffer.AsMemory(0, leidos), ct);
                bytesLeidos += leidos;

                if (totalBytes > 0)
                    progreso?.Report((double)bytesLeidos / totalBytes);
            }

            await streamDisk.FlushAsync(ct);

            // Verificar tamaño antes de mover
            if (bytesLeidos < TamanoMinimoBytes)
            {
                File.Delete(rutaTmp);
                throw new InvalidDataException(
                    $"El modelo descargado es demasiado pequeño ({bytesLeidos} bytes). " +
                    "Puede que la descarga se haya interrumpido.");
            }

            // Mover tmp → definitivo (operación atómica en la misma partición)
            if (File.Exists(RutaModelo))
                File.Delete(RutaModelo);

            File.Move(rutaTmp, RutaModelo);

            progreso?.Report(1.0);
            _logger.LogInformation("Modelo descargado correctamente ({Bytes} bytes).", bytesLeidos);
        }

        // ── Limpieza ──────────────────────────────────────────────────────────────

        /// <summary>Elimina el modelo del disco (para forzar re-descarga).</summary>
        public void Eliminar()
        {
            if (File.Exists(RutaModelo))
            {
                File.Delete(RutaModelo);
                _logger.LogInformation("Modelo eliminado.");
            }

            string rutaTmp = RutaModelo + ".tmp";
            if (File.Exists(rutaTmp))
                File.Delete(rutaTmp);
        }
    }
}
