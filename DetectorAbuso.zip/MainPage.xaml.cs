using DetectorAbuso.Models;
using DetectorAbuso.Servicios;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace DetectorAbuso
{
    public partial class MainPage : ContentPage
    {
        private readonly MonitorServ _monitorServ;

        public ObservableCollection<Incidente> IncidentesAbiertos  { get; } = new();
        public ObservableCollection<Incidente> IncidentesGuardados { get; } = new();

        public ICommand ArchivarCommand       { get; }
        public ICommand EliminarAbiertCommand { get; }

        // ── Constructor ───────────────────────────────────────────────────────────
        public MainPage(MonitorServ monitorServ)
        {
            InitializeComponent();
            BindingContext = this;

            _monitorServ = monitorServ;
            _monitorServ.IncidenteDetectado += OnIncidenteDetectado;

            ArchivarCommand       = new Command<Incidente>(ArchivarIncidente);
            EliminarAbiertCommand = new Command<Incidente>(EliminarAbierto);

            IncidentesAbiertosLista.ItemsSource  = IncidentesAbiertos;
            IncidentesGuardadosLista.ItemsSource = IncidentesGuardados;

            CargarDatosEjemplo();
        }

        // ── Datos de ejemplo (retirar cuando Whisper esté integrado) ──────────────
        private void CargarDatosEjemplo()
        {
            IncidentesAbiertos.Add(new Incidente
            {
                Fecha         = DateTime.Now,
                Probabilidad  = 75,
                Transcripcion = "eres inútil",
                Categorias    = "insulto"
            });
            IncidentesGuardados.Add(new Incidente
            {
                Fecha         = DateTime.Now.AddDays(-1),
                Probabilidad  = 82,
                Transcripcion = "si no te gusta te vas",
                Categorias    = "coercion"
            });
        }

        // ── Botones ───────────────────────────────────────────────────────────────
        private async void Monitorizar(object sender, EventArgs e)
        {
            if (_monitorServ.EstaActivo)
            {
                await DisplayAlertAsync("Ambiente", "El sensor ya está activo.", "OK");
                return;
            }

            bool ok = await _monitorServ.IniciarAsync();
            if (!ok)
            {
                await DisplayAlertAsync(
                    "Ambiente",
                    "Se necesita acceso al micrófono para activar el sensor.\nActívalo en Ajustes > Aplicaciones.",
                    "OK");
                return;
            }

            ActualizarEstadoLabel(activo: true);
        }

        private async void Parar(object sender, EventArgs e)
        {
            if (!_monitorServ.EstaActivo)
            {
                await DisplayAlertAsync("Ambiente", "El sensor ya está inactivo.", "OK");
                return;
            }

            await _monitorServ.DetenerAsync();
            ActualizarEstadoLabel(activo: false);
        }

        // ── Receptor de incidentes ────────────────────────────────────────────────
        private void OnIncidenteDetectado(Incidente incidente)
        {
            MainThread.BeginInvokeOnMainThread(async () =>
            {
                IncidentesAbiertos.Insert(0, incidente);
                await DisplayAlertAsync("Ambiente", "Nuevo momento registrado.", "Ver");
            });
        }

        // ── Acciones SwipeView ────────────────────────────────────────────────────
        private void ArchivarIncidente(Incidente? inc)
        {
            if (inc == null || !IncidentesAbiertos.Contains(inc)) return;
            IncidentesAbiertos.Remove(inc);
            IncidentesGuardados.Insert(0, inc);
        }

        private void EliminarAbierto(Incidente? inc)
        {
            if (inc == null) return;
            IncidentesAbiertos.Remove(inc);
        }

        // ── UI ────────────────────────────────────────────────────────────────────
        private void ActualizarEstadoLabel(bool activo)
        {
            if (EstadoLabel == null) return;
            EstadoLabel.Text      = activo ? "ACTIVO"   : "INACTIVO";
            EstadoLabel.TextColor = activo
                ? Color.FromArgb("#7BAF8E")
                : Color.FromArgb("#5A7080");
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            _monitorServ.IncidenteDetectado -= OnIncidenteDetectado;
        }
    }
}
